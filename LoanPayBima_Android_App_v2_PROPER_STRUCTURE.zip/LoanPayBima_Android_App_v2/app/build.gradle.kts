plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="in.loanpaybima.app"
    compileSdk=35
    defaultConfig {
        applicationId="in.loanpaybima.app"
        minSdk=26
        targetSdk=35
        versionCode=1
        versionName="1.0"
    }
    buildFeatures { viewBinding=true }
    kotlinOptions { jvmTarget="17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
}
