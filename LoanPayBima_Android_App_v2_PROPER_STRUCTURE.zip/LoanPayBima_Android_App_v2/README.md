# LoanPayBima Android App v2

Proper Android project structure for LoanPayBima.

Included:
- Splash screen with LoanPayBima branding
- Customer / Partner / Admin role selection
- Customer Mobile/Email + Password login UI
- Customer dashboard
- Insurance on EMI
- Car Insurance
- Bike Insurance
- Commercial Vehicle Insurance
- WhatsApp support
- Partner login through existing LoanPayBima website
- Admin login through WordPress admin
- GitHub Actions workflow for APK build without Android Studio

## Important
Customer authentication is currently a UI/demo flow. Real account verification requires a secure WordPress REST/JWT (or equivalent) API. Razorpay production integration should use server-side order creation and payment verification.

Read `GITHUB_UPLOAD_INSTRUCTIONS.txt` before uploading to GitHub.
